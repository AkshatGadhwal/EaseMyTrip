-- create table last_id (user_id int, booking_id int)
-- insert into last_id values (0, 0)


-- create a table with integer columns user_id and booking_id
-- create table last_id (user_id int, booking_id int)
