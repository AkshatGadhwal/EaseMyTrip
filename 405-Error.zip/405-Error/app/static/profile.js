// $(document).ready(function() {
//     // Display user data on the page
//     document.getElementById("user_id").innerHTML = "{{ user_data[0] }}";
//     document.getElementById("username").innerHTML = "{{ user_data[1] }}";
//     document.getElementById("email").innerHTML = "{{ user_data[2] }}";
//     //document.getElementById("password").innerHTML = "{{ user_data[3] }}";
//     //document.getElementById("is_admin").innerHTML = "{{ user_data[4] }}";
//     //document.getElementById("deletebutton").addEventListener("click", confirmDelete);
        
    
// }


// );
// function confirmDelete() {
//     if (confirm("Are you sure you want to delete your account?")) {
//         // If user confirms deletion, redirect to delete account route
//          window.location.href = "/delete_profile/{{ user_data[0] }};"
//         //window.location.href = "/profile"
        
//     }
// }
// function EditProfile() {
    
//     // If user confirms deletion, redirect to delete account route
//      window.location.href = "/update_profile/{{ user_data[0] }};"
//     //window.location.href = "/profile"
// }