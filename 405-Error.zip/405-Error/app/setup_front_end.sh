pip install Flask
pip install -U Flask-WTF
pip install psycopg2
