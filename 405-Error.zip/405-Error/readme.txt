Existing registered users :

 user_id | username |         email          |   upassword   | is_admin
---------+----------+------------------------+---------------+----------
  123456 | admin    | test@example.com       | admin         | t
 1234568 | dummy3   | dummy3@example.com     | dummy3        | f
 1234569 | 1234     | test2@example.com      | 69UQgjzmsZKq8 | f
 1234570 | 1235     | test3@example.com      | password      | f
 1234572 | diboo    | abc@ex.com             | diboo         | f
  123457 | dummy4   | dummy2@example.com     | dummy4        | t
 1234573 | dEEM     | deem@xyz.com           | deem          | f
 1234574 | vijay    | vijay@testing.com      | vijay         | f
 1234571 | divya    | rana123divya@gmail.com | divya         | f
 
 (entries from users table)
 
 Existing flight bookings for these users :
 
 flight_id | user_id | booking_id | is_cancelled
-----------+---------+------------+--------------
    385920 |  123456 |        998 | f
      3840 |  123456 |          1 | f
    123457 |         |     123458 | f
    136333 |  123457 |     123459 | f
    246649 |  123457 |     123460 | f
    136333 |  123457 |     123462 | f
    195556 |  123457 |     123463 | f
    246697 | 1234573 |     123464 | f
    246649 | 1234573 |     123465 | f
    172968 |  123457 |     123466 | f
      8721 |  123457 |     123467 | f
     11140 | 1234571 |     123469 | f
    722145 |  123457 |     123470 | f
    721625 |  123457 |     123471 | f
    713746 |  123457 |     123472 | f
    650150 |  123457 |     123473 | f
    649607 |  123457 |     123474 | f
    
Existing hotel bookings for these users :
    
     hotel_id | user_id | start_date |  end_date  | is_cancelled | booking_id
----------+---------+------------+------------+--------------+------------
        1 |  123456 | 2021-07-20 | 2021-07-22 | f            |       1000
        2 |  123457 | 2021-07-20 | 2021-07-22 | f            |       1001
     1850 |  123456 | 2022-04-16 | 2022-04-18 | f            |          1
     1197 |  123457 | 2023-04-05 | 2023-04-07 | f            |       1004
     1200 | 1234573 | 2023-04-06 | 2023-05-12 | f            |       1005
     1075 |  123457 | 2023-04-26 | 2023-04-29 | f            |       1006
     1197 | 1234571 | 2023-04-06 | 2023-04-10 | f            |       1007
