drop table airport_codes cascade;
drop table flights cascade;
drop table hotels cascade;
drop table reviews cascade;
drop table cities cascade;
drop table hotel_booking cascade;
drop table flight_booking cascade;
drop table users cascade;
